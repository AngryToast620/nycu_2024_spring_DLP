import warnings

# Suppress all warnings
warnings.filterwarnings("ignore")

import os
from pathlib import Path
import torch
from dcgan import Generator
from evaluator import evaluation_model
from util import get_test_conditions, save_image

device = 'cuda' if torch.cuda.is_available() else 'cpu'

z_dim = 100
c_dim = 200
g_times = 4

test_path = Path('../dataset/test.json')
new_test_path = Path('../dataset/new_test.json')
generator_path = Path('./models') / 'epoch394_0.72_0.67.pt'  # need to fix path


if __name__ == '__main__':

    # load testing data condition
    conditions = get_test_conditions(test_path).to(device)  # (N, 24) tensor

    eval_model = evaluation_model()

    # load generator model
    g_model = Generator(z_dim, c_dim).to(device)
    g_model.load_state_dict(torch.load(generator_path))

    # evaluate
    avg_score = 0
    # for _ in range(10):
    z = torch.randn(len(conditions), z_dim).to(device)  # (N, 100) tnesor
    gen_img = g_model(z, conditions)

    score = eval_model.eval(gen_img, conditions)

    print(f'test score: {score:.2f}')
    avg_score += score

    save_image(gen_img, 'test.png', nrow=8, normalize=True)
    
    # print('----------------------------')
    # print(f'avg score: {avg_score / 10 :.2f}')  

    conditions = get_test_conditions(new_test_path).to(device)  # (N, 24) tensor

    eval_model = evaluation_model()

    # load generator model
    g_model = Generator(z_dim, c_dim).to(device)
    g_model.load_state_dict(torch.load(generator_path))

    # evaluate
    avg_score = 0
    # for _ in range(10):
    z = torch.randn(len(conditions), z_dim).to(device)  # (N, 100) tnesor
    gen_img = g_model(z, conditions)

    score = eval_model.eval(gen_img, conditions)

    print(f'new test score: {score:.2f}')
    avg_score += score

    save_image(gen_img, 'new_test.png', nrow=8, normalize=True)