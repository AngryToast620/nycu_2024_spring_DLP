from torch.utils.data import DataLoader
from util import get_test_conditions
from datahelper import CLEVRDataset

print(get_test_conditions('dataset/test.json'))