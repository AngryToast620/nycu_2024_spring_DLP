from pathlib import Path
import torch
from torch.utils.data import DataLoader

from datahelper import CLEVRDataset
from dcgan import Generator, Discriminator
from train import train

device = 'cuda' if torch.cuda.is_available() else 'cpu'

z_dim = 100
c_dim = 200
image_shape = (64, 64, 3)
epochs = 500
lr = 0.0002
batch_size = 512


if __name__ == '__main__':
    # load training data
    dataset_train = CLEVRDataset(img_path='../iclevr', json_path=Path('../dataset/train.json'))
    loader_train = DataLoader(dataset_train, batch_size=batch_size, shuffle=True, num_workers=2)

    # init generator and discriminator
    generator = Generator(z_dim, c_dim).to(device)
    discriminator = Discriminator(image_shape).to(device)
    generator.weight_init(mean=0, std=0.02)
    discriminator.weight_init(mean=0, std=0.02)

    # train step
    train(loader_train, generator, discriminator, z_dim, epochs, lr)