from pathlib import Path
import math
import json
from PIL import Image
import torch

irange = range


def get_test_conditions(path):
    '''
    return: (number of test conditions, number of classes) tensors
    '''
    with open(Path('../dataset/objects.json'), 'r') as file:
        classes = json.load(file)
    with open(path, 'r') as file:
        test_conditions_list = json.load(file)

    labels = torch.zeros(len(test_conditions_list), len(classes))
    for i in range(len(test_conditions_list)):
        for condition in test_conditions_list[i]:
            labels[i, int(classes[condition])] = 1.

    return labels

def make_grid(tensor, nrow=8, padding=2, normalize=False, range=None, scale_each=False, pad_value=0):
    if not (torch.is_tensor(tensor) or (isinstance(tensor, list) and all(torch.is_tensor(t) for t in tensor))):
        raise TypeError('tensor or list of tensors expected, got {}'.format(type(tensor)))
    

    # if list of tensors, convert to a 4D mini-batch Tensor
    if isinstance(tensor, list):
        tensor = torch.stack(tensor, dim=0)

    # no color channel
    if tensor.dim() == 2:
        tensor = tensor.unsqueeze(0)

    # number of color channel only 1 
    if tensor.dim() == 3:
        if tensor.size(0) == 1:
            tensor = torch.cat((tensor, tensor, tensor), 0)
        tensor = tensor.unsqueeze(0)

    # number of color channel only 1
    if tensor.dim() == 4 and tensor.size(1) == 1:
        tensor = torch.cat((tensor, tensor, tensor), 1)

    if normalize is True:
        tensor = tensor.clone()     # avoid modifying tensor in-place
        if range is not None:
            assert isinstance(range, tuple), "range has to be a tuple (min, max) if specified. min and max are numbers"

        def norm_ip(img, min, max):
            img.clamp_(min=min, max=max)
            img.add_(-min).div_(max - min + 1e-5)

        def norm_range(t, range):
            if range is not None:
                norm_ip(t, range[0], range[1])
            else: 
                norm_ip(t, float(t.min()), float(t.max()))

        if scale_each is True:
            for t in tensor:
                norm_range(t, range)
        else:
            norm_range(tensor, range)


    if tensor.size(0) == 1:
        return tensor.squeeze(0)
    
    # make the mini-batch of images into a grid
    nmaps = tensor.size(0)  # batch_size of list, or channel num of single img
    xmaps = min(nrow, nmaps)
    # print(nmaps, xmaps)
    ymaps = int(math.ceil(float(nmaps) / xmaps))
    # print(ymaps)
    height, width = int(tensor.size(2) + padding), int(tensor.size(3) + padding)
    num_channels = tensor.size(1)
    grid = tensor.new_full((num_channels, height * ymaps + padding, width * xmaps + padding), pad_value)
    k = 0
    for y in irange(ymaps):
        for x in irange(xmaps):
            if k >= nmaps:
                break
            grid.narrow(1, y * height + padding, height - padding)\
                .narrow(2, x * width + padding, width - padding)\
                .copy_(tensor[k])
            k = k + 1
    return grid


def save_image(tensor, fp, nrow=8, padding=2, normalize=False, range=None, scale_each=False, pad_value=0, format=None):
    grid = make_grid(tensor, nrow=nrow, padding=padding, normalize=normalize, range=range, scale_each=scale_each, pad_value=pad_value)
    #  add 0.5 after unnormalizing to [0, 255] to round to nearest integer
    ndarr = grid.mul(255).add_(0.5).clamp_(0, 255).permute(1, 2, 0).to('cpu', torch.uint8).numpy()
    im = Image.fromarray(ndarr)
    im.save(fp, format=format)


# compute the current classification accuracy
def compute_acc(out, onehot_labels):
    batch_size = out.size(0)
    acc = 0
    total = 0
    for i in range(batch_size):
        k = int(onehot_labels[i].sum().item())
        total += k
        outv, outi = out[i].topk(k)
        lv, li = onehot_labels[i].topk(k)
        for j in outi:
            if j in li:
                acc += 1
    return acc / total