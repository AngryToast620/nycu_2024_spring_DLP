from pathlib import Path
import torch
import torch.nn as nn
import copy

from util import get_test_conditions, save_image
from evaluator import evaluation_model

device = 'cuda' if torch.cuda.is_available() else 'cpu'


def train(dataloader, g_model, d_model, z_dim, epochs, lr):
    criterion = nn.BCELoss()
    optimizer_g = torch.optim.Adam(g_model.parameters(), lr, betas=(0.5, 0.99))
    optimizer_d = torch.optim.Adam(d_model.parameters(), lr, betas=(0.5, 0.99))

    # scheduler_g = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer_g, factor=0.1, patience=5, min_lr=1e-6)
    # scheduler_d = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer_d, factor=0.1, patience=5, min_lr=1e-6)

    eval_model = evaluation_model()

    test_conditions = get_test_conditions(Path('../dataset/test.json')).to(device)
    new_test_conditions = get_test_conditions(Path('../dataset/new_test.json')).to(device)
    fixed_z = torch.randn(len(test_conditions), z_dim).to(device)
    best_score = 0
    best_score_new = 0

    for epoch in range(1, 1 + epochs):
        total_los_g = 0
        total_los_d = 0
        
        g_model.train()
        d_model.train()
        for i, (images, conditions) in enumerate(dataloader):
            batch_size = len(images)
            
            images = images.to(device)
            conditions = conditions.to(device)

            # dcgan
            real = torch.ones(batch_size).to(device)
            fake = torch.zeros(batch_size).to(device)

            ## train discriminator 1 times

            # for real images
            predicts = d_model(images, conditions)

            loss_real = criterion(predicts, real)

            # for fake images
            z = torch.randn(batch_size, z_dim).to(device)

            gen_imgs = g_model(z, conditions)
            predicts = d_model(gen_imgs.detach(), conditions)

            loss_fake = criterion(predicts, fake)

            loss_d = loss_real + loss_fake
            
            optimizer_d.zero_grad()

            loss_d.backward()

            optimizer_d.step()
            # scheduler_d.step(loss_d)

            g_times = 4

            ## train generator g_times times
            for _ in range(g_times):
                z = torch.randn(batch_size, z_dim).to(device)

                gen_imgs = g_model(z, conditions)
                predicts = d_model(gen_imgs, conditions)

                loss_g = criterion(predicts, real)
                
                optimizer_g.zero_grad()

                loss_g.backward()

                optimizer_g.step()
                # scheduler_g.step(loss_g)

            print(f'epoch{epoch} {i+1}/{len(dataloader)} loss_g: {loss_g.item():.3f} loss_d: {loss_d.item():.3f}')
            total_los_d += loss_d.item()
            total_los_g += loss_g.item()

        
        # evaluate
        g_model.eval()
        d_model.eval()
        with torch.no_grad():
            gen_imgs = g_model(fixed_z, test_conditions)
            gen_imgs_new = g_model(fixed_z, new_test_conditions)

        score = eval_model.eval(images=gen_imgs, labels=test_conditions)
        score_new = eval_model.eval(images=gen_imgs_new, labels=new_test_conditions)
        if score > best_score or score_new > best_score_new:
            if score > best_score:
                best_score = score
            else:
                best_score_new = score_new
            best_model_wts = copy.deepcopy(g_model.state_dict())
            model_path = Path('models')
            torch.save(best_model_wts, model_path / f'epoch{epoch}_{score:.2f}_{score_new:.2f}.pt')
        
        print(f'avg loss_g: {total_los_g / len(dataloader) :.3f} avg loss_d: {total_los_d / len(dataloader) :.3f}')
        print(f'testing score: {score:.2f}')
        print('--------------------------------------------')

        # save figure
        figure_path = Path('results')
        save_image(gen_imgs, figure_path / f'epoch{epoch}.png', nrow=8, normalize=True)