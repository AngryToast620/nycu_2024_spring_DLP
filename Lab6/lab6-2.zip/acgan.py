import torch
import torch.nn as nn

class Discriminator(nn.Module):
    def __init__(self, img_shape, hidden_num=64):
        super().__init__()
        self.H, self.W, self.C = img_shape
        self.n_classes = 24
        self.hidden_num = hidden_num
        self.main = nn.Sequential(
            # input is (rgb chnannel = 3) x 64 x 64
            nn.Conv2d(3, self.hidden_num, 3, 2, 1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(0.5, inplace=False),
            # state size. (ndf) x 32 x 32
            nn.Conv2d(self.hidden_num, self.hidden_num * 2, 3, 1, 0, bias=False),
            nn.BatchNorm2d(self.hidden_num * 2),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(0.5, inplace=False),
            # state size. (ndf*2) x 30 x 30
            nn.Conv2d(self.hidden_num * 2, self.hidden_num * 4, 3, 2, 1, bias=False),
            nn.BatchNorm2d(self.hidden_num * 4),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(0.5, inplace=False),
            # state size. (ndf*4) x 16 x 16
            nn.Conv2d(self.hidden_num * 4, self.hidden_num * 8, 3, 1, 0, bias=False),
            nn.BatchNorm2d(self.hidden_num * 8),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(0.5, inplace=False),
            # state size. (ndf*8) x 14 x 14
            nn.Conv2d(self.hidden_num * 8, self.hidden_num * 16, 3, 2, 1, bias=False),
            nn.BatchNorm2d(self.hidden_num * 16),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(0.5, inplace=False),
            # state size (ndf*16) x 8 x 8
            nn.Conv2d(self.hidden_num * 16, self.hidden_num * 32, 3, 1, 0, bias=False),
            nn.BatchNorm2d(self.hidden_num * 32),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(0.5, inplace=False),
        )

        # fc
        self.fc_dis = nn.Sequential(
            nn.Linear(5 * 5 * self.hidden_num * 32, 1),
            nn.Sigmoid()
        )
        # aux-classifier fc
        self.fc_aux = nn.Sequential(
            nn.Linear(5 * 5 * self.hidden_num * 32, self.n_classes),
            nn.Sigmoid()
        )

    def forward(self, x):
        out = self.main(x)
        out = out.view(-1, 5 * 5 * self.hidden_num * 32)
        out1 = self.fc_dis(out).view(-1, 1).squeeze(1)
        out2 = self.fc_aux(out)
        return out1, out2
    
    def weight_init(self, mean, std):
        for m in self._modules:
            if isinstance(self._modules[m], nn.ConvTranspose2d) or isinstance(self._modules[m], nn.Conv2d):
                self._modules[m].weight.data.normal_(mean, std)
                self._modules[m].bias.data.zero_()


class Generator(nn.Module):
    def __init__(self, z_dim, c_dim, hidden_num=300):
        super().__init__()
        self.z_dim = z_dim
        self.c_dim = c_dim
        self.hidden_num = hidden_num
        self.conditionExpand = nn.Sequential(
            nn.Linear(24, c_dim),
            nn.LeakyReLU(0.2, True)
        )

        self.main = nn.Sequential(
            # input is Z, going into a convolution
            nn.ConvTranspose2d(self.z_dim + self.c_dim, self.hidden_num * 8, 4, 1, 0, bias=False),
            nn.BatchNorm2d(self.hidden_num * 8),
            nn.ReLU(True),
            # state size. (ngf*8) x 4 x 4
            nn.ConvTranspose2d(self.hidden_num * 8, self.hidden_num * 4, 4, 2, 1, bias=False),
            nn.BatchNorm2d(self.hidden_num * 4),
            nn.ReLU(True),
            # state size. (ngf*4) x 8 x 8
            nn.ConvTranspose2d(self.hidden_num * 4, self.hidden_num * 2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(self.hidden_num * 2),
            nn.ReLU(True),
            # state size. (ngf*2) x 16 x 16
            nn.ConvTranspose2d(self.hidden_num * 2, self.hidden_num, 4, 2, 1, bias=False),
            nn.BatchNorm2d(self.hidden_num),
            nn.ReLU(True),
            # state size. (ngf) x 32 x 32
            nn.ConvTranspose2d(self.hidden_num, 3, 4, 2, 1, bias=False),
            nn.Tanh()
            # state size. (rgb channel = 3) x 64 x 64
        )


    def forward(self, z, c):
        z = z.view(-1, self.z_dim, 1, 1)
        c = self.conditionExpand(c).view(-1, self.c_dim, 1, 1)
        gen_input = torch.cat((z, c), 1)
        out = self.main(gen_input)
        return out
    

    def weight_init(self, mean, std):
        for m in self._modules:
            if isinstance(self._modules[m], nn.ConvTranspose2d) or isinstance(self._modules[m], nn.Conv2d):
                self._modules[m].weight.data.normal_(mean, std)
                self._modules[m].bias.data.zero_()