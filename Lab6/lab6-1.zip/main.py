import warnings

warnings.filterwarnings("ignore", category=UserWarning, module='torchvision.models._utils')

from evaluator import evaluation_model
from dataloader import iclevrLoader
import argparse
import torch
import torch.nn as nn
from torchvision import transforms
import torchvision
from torchvision.utils import save_image
from diffusers import UNet2DModel
import random

from accelerate import Accelerator
from diffusers.optimization import get_cosine_schedule_with_warmup

timestep = 1200
beta = torch.linspace(1e-4, .002, timestep) # recommend 1e-4 to .002, timespace=2000
alpha = 1 - beta
alpha_cumprod = torch.cumprod(alpha, dim=0)
sqrt_alpha_cumprod = torch.sqrt(alpha_cumprod)
sqrt_oneminus_alpha_cumprod = torch.sqrt(1 - alpha_cumprod)

one_minus_alpha_cumprod_t_minus_1 =  torch.cat((torch.tensor(1).unsqueeze(0), (1 - alpha_cumprod)[:-1]))
one_minus_alpha_cumprod = (1 - alpha_cumprod)
sqrt_variance =  torch.sqrt((beta * (one_minus_alpha_cumprod_t_minus_1/one_minus_alpha_cumprod)))
# print(sqrt_variance.shape)


def compute_xt(args, data, rand_t, noise):
    # caculate coef
    coef_x0 = []
    coef_noise = []
    # select coef
    for i in range(data.shape[0]):
        coef_x0.append(sqrt_alpha_cumprod[rand_t[i]-1])
        coef_noise.append(sqrt_oneminus_alpha_cumprod[rand_t[i]-1])
    coef_x0 = torch.tensor(coef_x0)
    coef_noise = torch.tensor(coef_noise)
    
    coef_x0 = coef_x0[:, None, None, None].to(args.device)
    coef_noise = coef_noise[:, None, None, None].to(args.device)
    data = data.to(args.device)
    noise = noise.to(args.device)
    
    return coef_x0 * data + coef_noise * noise


def train(args, model, device, train_loader, optimizer, epoch, lr_scheduler, accelerator):
    model.train()          
    criterion = nn.MSELoss()

    for batch_idx, (data, cond) in enumerate(train_loader):
        data, cond = data.to(device, dtype=torch.float32), cond.to(device)
        cond = cond.squeeze()
        
        # select t
        rand_t = torch.tensor([random.randint(1, timestep) for i in range(data.shape[0])])
        # select noise
        noise = torch.randn(data.shape[0], 3, 64, 64).to(args.device)
        xt = compute_xt(args, data, rand_t, noise)
        
        xt = xt.to(args.device)
        rand_t = rand_t.to(args.device)
        cond = cond.to(torch.float32).to(args.device)

        output = model(sample=xt, timestep=rand_t, class_labels=cond) 
        loss = criterion(output.sample.to(args.device), noise)
        accelerator.backward(loss)

        optimizer.zero_grad()
        
        lr_scheduler.step()
        
        optimizer.step()

        if batch_idx % args.log_interval == 0:
            print(f'Train Epoch: {epoch} [{batch_idx * len(data)}/{len(train_loader.dataset)} ({((100 * batch_idx) / len(train_loader)):.0f}%)]\tLoss: {loss.item():.10f}')
    return

def compute_prev_x(xt, t, pred_noise, args):
    coef = 1 / torch.sqrt(alpha[t-1])
    noise_coef = beta[t-1] / sqrt_oneminus_alpha_cumprod[t-1]
    if t <= 1 :
        z = 0
    else:
        z = torch.randn(args.test_batch, 3, 64, 64)
    sqrt_var = sqrt_variance[t-1] 
    mean = coef * (xt - noise_coef * pred_noise)
    
    prev_x = mean.to("cpu") + sqrt_var.to("cpu") * z
    return prev_x


def save_images(images, name):
    grid = torchvision.utils.make_grid(images)
    save_image(grid, fp = "./"+name+".png")

def sample(model, device, test_loader, args, filename):
    # denormalize
    transform=transforms.Compose([
            transforms.Normalize((0, 0, 0), (2, 2, 2)),
            transforms.Normalize((-0.5, -0.5, -0.5), (1, 1, 1)),
        ])
    model.eval()
    xt = torch.randn(args.test_batch, 3, 64, 64)
    with torch.no_grad():
        for batch_idx, (img, cond) in enumerate(test_loader):
            cond = cond.to(device)
            # transform one-hot to embed's input
            cond = cond.squeeze()
            
            for t in range(timestep, 0, -1):
                xt = xt.to(args.device)
                cond = cond.to(torch.float32).to(args.device)

                # pred noise
                output = model(sample=xt, timestep=t, class_labels=cond)
                # compute xt-1
                xt = compute_prev_x(xt, t, output.sample.to(args.device), args)

            # evaluate
            evaluate = evaluation_model()

            xt = xt.to(args.device)
            cond.to(args.device)

            acc = evaluate.eval(xt, cond)
            torch.save(xt, f=filename+".pt")
            print(f"Test Result: {acc}")
            with open('{}.txt'.format(filename), 'a') as test_record:
                test_record.write((f'Accuracy : {acc}\n'))
            # denormalize
            img = transform(xt)
            save_images(img, name=filename)
            

        

def main():
    # Training settings
    parser = argparse.ArgumentParser(description='PyTorch MNIST Example')
    parser.add_argument('-d', '--device', default='cuda')
    parser.add_argument('--train_batch', type=int, default=64)
    parser.add_argument('--test_batch', type=int, default=32)
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--lr', type=float, default=1e-4 * 0.5)
    parser.add_argument('--gamma', type=float, default=0.7)
    parser.add_argument('--log-interval', type=int, default=10)
    parser.add_argument('--save-model', action='store_true', default=True)


    args = parser.parse_args()
    device = torch.device(args.device)
    train_kwargs = {'batch_size': args.train_batch}
    test_kwargs = {'batch_size': args.test_batch}

    #manipulate data
    train_loader = torch.utils.data.DataLoader(iclevrLoader(root="../dataset/", mode="train"),**train_kwargs,shuffle=True)
    # print(len(train_loader.dataset))
    test_loader = torch.utils.data.DataLoader(iclevrLoader(root="../dataset/", mode="test"),**test_kwargs,shuffle=False)
    test_loader_new = torch.utils.data.DataLoader(iclevrLoader(root="../dataset/", mode="new_test"),**test_kwargs,shuffle=False)

    # create model
    model = UNet2DModel(
        sample_size = 64,
        in_channels = 3,
        out_channels = 3,
        layers_per_block = 2,
        class_embed_type = None,
        block_out_channels = (128, 128, 256, 256, 512, 512), 
        down_block_types=(
            "DownBlock2D",  # a regular ResNet downsampling block
            "DownBlock2D",
            "DownBlock2D",
            "DownBlock2D",
            "AttnDownBlock2D",  # a ResNet downsampling block with spatial self-attention
            "DownBlock2D",
        ),
        up_block_types=(
            "UpBlock2D",  # a regular ResNet upsampling block
            "AttnUpBlock2D",  # a ResNet upsampling block with spatial self-attention
            "UpBlock2D",
            "UpBlock2D",
            "UpBlock2D",
            "UpBlock2D",
        ),
    ).to(args.device)
    
    model.class_embedding = nn.Linear(24 ,512)
    # optimizer
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)
    lr_scheduler = get_cosine_schedule_with_warmup(
        optimizer=optimizer,
        num_warmup_steps=0,
        num_training_steps=len(train_loader)*500,
    )

    # Accelerator
    accelerator = Accelerator()
    model, optimizer, train_loader, lr_scheduler = accelerator.prepare(
        model, optimizer, train_loader, lr_scheduler
    )

    for epoch in range(1, args.epochs + 1):
        train(args, model, device, train_loader, optimizer, epoch, lr_scheduler, accelerator)
        if args.save_model and (epoch % 1)==0 :
            if args.save_model and (epoch % 5)==0 :
                model.save_pretrained("./local-unet"+"epoch_"+str(epoch), variant="non_ema")
            print("==test.json==")
            sample(model, device, test_loader, args, "test_"+str(epoch))
            # print("==test_new.json==")
            # sample(model, device, test_loader_new, args, "new_test_"+str(epoch))
            # model.save_pretrained("./local-unet"+"epoch_"+str(epoch), variant="non_ema")

    

if __name__ == '__main__':
    main()