import warnings

# Suppress all warnings
warnings.filterwarnings("ignore")

import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms

from torchvision.utils import save_image
import argparse

from evaluator import evaluation_model
from dataloader import iclevrLoader
from diffusers import UNet2DModel
from safetensors.torch import load_file as load_safetensors


timestep = 1200
beta = torch.linspace(1e-4, .002, timestep) # recommend 1e-4 to .002, timespace=2000
alpha = 1 - beta
alpha_cumprod = torch.cumprod(alpha, dim=0)
sqrt_oneminus_alpha_cumprod = torch.sqrt(1 - alpha_cumprod)

one_minus_alpha_cumprod_t_minus_1 =  torch.cat((torch.tensor(1).unsqueeze(0), (1 - alpha_cumprod)[:-1]))
one_minus_alpha_cumprod = (1 - alpha_cumprod)
sqrt_variance =  torch.sqrt((beta * (one_minus_alpha_cumprod_t_minus_1/one_minus_alpha_cumprod)))


def compute_prev_x(xt, t, pred_noise, args):
    coef = 1 / torch.sqrt(alpha[t-1])
    noise_coef = beta[t-1] / sqrt_oneminus_alpha_cumprod[t-1]
    if t <= 1 :
        z = 0
    else:
        z = torch.randn(args.test_batch, 3, 64, 64)
    sqrt_var = sqrt_variance[t-1] 
    mean = coef * (xt - noise_coef * pred_noise)
    
    prev_x = mean.to("cpu") + sqrt_var.to("cpu") * z
    return prev_x


def save_images(images, name):
    grid = torchvision.utils.make_grid(images)
    save_image(grid, fp = "./"+name+".png")

def sample(model, device, test_loader, args, root):
    # denormalize
    transform=transforms.Compose([
            transforms.Normalize((0, 0, 0), (2, 2, 2)),
            transforms.Normalize((-0.5, -0.5, -0.5), (1, 1, 1)),
        ])
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    model.eval()
    xt = torch.randn(args.test_batch, 3, 64, 64)
    outputs = []
    with torch.no_grad():
        for batch_idx, (img, cond) in enumerate(test_loader):
            cond = cond.to(device)
            # transform one-hot to embed's input
            cond = cond.squeeze()
            cond = cond.to(torch.float32).to(device)
            
            for t in range(timestep, 0, -1):
                xt = xt.to(device)

                # pred noise
                output = model(sample=xt, timestep=t, class_labels=cond)
                if t % 100 == 1:
                    outputs.append(xt)
                    # img = transform(xt)
                    # save_images(img, name=root)

                # compute xt-1
                xt = compute_prev_x(xt, t, output.sample.to(device), args)

            # evaluate
            evaluate = evaluation_model()
            xt = xt.to(device)
            acc = evaluate.eval(xt, cond)
            
            # denormalize
            img = transform(xt)
            print(img.shape)
            save_images(img, name='test_result')

            outputs = torch.stack(outputs)
            outputs = outputs.squeeze()
            outputs = transform(outputs)
            print(outputs.shape)
            save_images(outputs, name=root)

            # for i, out in enumerate(outputs):
            #     out = out.unsqueeze(0)  
            #     out = transform(out)  
            #     save_images(out, name=f'{root}_step_{i*100}')

            break
        return acc


def main():
    parser = argparse.ArgumentParser(description='PyTorch MNIST Example')
    parser.add_argument('--test_batch', type=int, default=1)
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--lr', type=float, default=1e-4 * 0.5)
    parser.add_argument('--log-interval', type=int, default=10)

    args = parser.parse_args()
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    test_kwargs = {'batch_size': args.test_batch}

    test_loader = torch.utils.data.DataLoader(iclevrLoader(root="../dataset/", mode="test"), **test_kwargs, shuffle=False)
    new_test_loader = torch.utils.data.DataLoader(iclevrLoader(root="../dataset/", mode="new_test"), **test_kwargs, shuffle=False)

    # create model
    model = UNet2DModel(
        sample_size = 64,
        in_channels = 3,
        out_channels = 3,
        layers_per_block = 2,
        class_embed_type = None,
        block_out_channels = (128, 128, 256, 256, 512, 512), 
        down_block_types=(
            "DownBlock2D",  # a regular ResNet downsampling block
            "DownBlock2D",
            "DownBlock2D",
            "DownBlock2D",
            "AttnDownBlock2D",  # a ResNet downsampling block with spatial self-attention
            "DownBlock2D",
        ),
        up_block_types=(
            "UpBlock2D",  # a regular ResNet upsampling block
            "AttnUpBlock2D",  # a ResNet upsampling block with spatial self-attention
            "UpBlock2D",
            "UpBlock2D",
            "UpBlock2D",
            "UpBlock2D",
        ),
    ).to(device)

    model.class_embedding = nn.Linear(24 ,512)

    # load model
    state_dict = load_safetensors('local-unetepoch_105/diffusion_pytorch_model.non_ema.safetensors')
    model = UNet2DModel.from_pretrained(pretrained_model_name_or_path ="local-unetepoch_105",  
        variant="non_ema", from_tf=True, low_cpu_mem_usage=False, ignore_mismatched_sizes=True)
    # print(model.class_embedding)
    model.class_embedding = nn.Linear(24 ,512)
    filtered_state_dict = {k[16:]: v for k, v in state_dict.items() if k == "class_embedding.weight" or k == "class_embedding.bias"}

    model.class_embedding.load_state_dict(filtered_state_dict)

    model = model.to(device)

    model.eval()

    with torch.no_grad():
        print("====test.json====")
        acc = sample(model, device, test_loader, args, 'test')
        print(f'Test score: {acc:.3f}')

        print("====new_test.json====")
        acc = sample(model, device, new_test_loader, args, 'new_test')
        print(f'New test score: {acc:.3f}')



if __name__ == '__main__':
    main()